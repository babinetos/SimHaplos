/* Includes a binary covariate and its interactions with haplotypes */

//generates cases and controls. 
//1. Simulates a haplotype pair using HWD model
   //Note:a.HAPLOTYPE PAIR, NOT HAPLOTYPE!!!
   //Note:b.Last haplotype is the most frequent and used as reference.
//2. Then assign it to either case or control using logistic regression model with OR specified. 
//3. Output

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "ranlib.h"
#include <time.h>

unsigned long long rdtsc();

int main(int arg, char **data)
{
  int num_cases, num_controls, i, j, k, num_hap, length_hap, **hap, tot_hap_pair, **hap_index, select_hap_pair, hap1, hap2, *genSNP, *x, y, tot_samp, *sample_y, **sample_SNP, *sample_hap1, *sample_hap2, *sample_cov, count;
  long *gen_hap_pair, n1=0, n2=0;
  double d, base_prev, *odds_ratio, *f0, *f1, sum_hap=0, logitp, *beta, prob_case;
  float *hap_prob0_pair, *hap_prob1_pair, prev_cov;
  FILE *infile, *outfile;
  long iseed1, iseed2, div, num;
   
  iseed1 = time(NULL)+getpid();
  iseed2 = iseed1+time(NULL)%13;

  setall(iseed1,iseed2);

  infile = fopen(data[1], "r");
  fscanf(infile, "%d%d%d%d%lf%lf", &num_hap, &length_hap, &num_cases, &num_controls, &base_prev, &d);

  hap=calloc(num_hap, sizeof(int*));
  for (i=0; i<num_hap; ++i)
    hap[i]=calloc(length_hap, sizeof(int));  
  for (i=0; i<num_hap; ++i)
    {
      for (j=0; j<length_hap; ++j)
	{
	  fscanf(infile, "%d", &hap[i][j]);
	}
    }
 
  f0=calloc(num_hap, sizeof(double));
  f1=calloc(num_hap, sizeof(double)); 
  odds_ratio=calloc(2*(num_hap-1)+1, sizeof(double)); /* Includes all OR's */
  for (i=0; i<num_hap; ++i) /* Read frequency & OR of all haplotypes including baseline */
    {
      fscanf(infile, "%lf", &f0[i]);
      fscanf(infile, "%lf", &f1[i]); 
      fscanf(infile, "%lf", &odds_ratio[i]);
    } 
  fscanf(infile, "%f", &prev_cov); /* Prevalence of covariate */
  fscanf(infile, "%lf", &odds_ratio[num_hap-1]); /* Overwriting the OR of baseline (last) haplotype with the OR for covariate */

  for (i=num_hap; i<2*(num_hap-1)+1; ++i) /* OR for interaction terms */
    {
      fscanf(infile, "%lf", &odds_ratio[i]);
    }

  fclose(infile);

  /* Number of possible haplotype pairs & their probabilities */
  tot_hap_pair = num_hap*(num_hap+1)/2;
  hap_prob0_pair = calloc(tot_hap_pair, sizeof(float));
  hap_prob1_pair = calloc(tot_hap_pair, sizeof(float));

  hap_index = calloc(tot_hap_pair, sizeof(int*));
  for (i=0; i<tot_hap_pair; ++i)
    hap_index[i] = calloc(2, sizeof(int));
 
  k=0;
  for (i=0; i<num_hap; ++i)
    {
      for (j=i; j<num_hap; ++j)
	{
	  if (i==j) 
	    {
	      
	      hap_prob0_pair[k] = d*f0[i]+(1-d)*pow(f0[i],2);
	      hap_prob1_pair[k] = d*f1[i]+(1-d)*pow(f1[i],2);
	    }
	  else
	    {
	      hap_prob0_pair[k] = 2*(1-d)*f0[i]*f0[j];
	      hap_prob1_pair[k] = 2*(1-d)*f1[i]*f1[j];
	    }
	  hap_index[k][0] = i;
	  hap_index[k][1] = j;
	  ++k;
	}
    }

  /* Allocate space for storing the overall sample */
  sample_y = calloc(num_cases+num_controls, sizeof(int));
  sample_SNP = calloc(num_cases+num_controls, sizeof(int*));
  for (i=0; i<num_cases+num_controls; ++i)
    sample_SNP[i] = calloc(2*length_hap, sizeof(int));

  sample_hap1 = calloc(num_cases+num_controls, sizeof(int));
  sample_hap2 = calloc(num_cases+num_controls, sizeof(int));

  sample_cov = calloc(num_cases+num_controls, sizeof(int));

  /* Sample until the total # of cases and controls are met */
  tot_samp = 0;
  while (tot_samp < num_cases+num_controls)
    {
      x = calloc(2*(num_hap-1)+1, sizeof(int));
      x[num_hap-1] = ignbin(1, (float) prev_cov);
      gen_hap_pair = calloc(tot_hap_pair, sizeof(long));
      if(x[num_hap-1] == 0)
          {genmul(1, hap_prob0_pair, (long) tot_hap_pair, gen_hap_pair);}
      else{genmul(1, hap_prob1_pair, (long) tot_hap_pair, gen_hap_pair);}

      for (i=0; i<tot_hap_pair; ++i)
	{
	  if (gen_hap_pair[i] == 1) select_hap_pair = i;
	}
      hap1 = hap_index[select_hap_pair][0];
      hap2 = hap_index[select_hap_pair][1];
      
      genSNP = calloc(2*length_hap, sizeof(int));     
      i = 0;
      for (j=0; j<length_hap; ++j)
	{
	  genSNP[i] = hap[hap1][j];
	  genSNP[i+1] = hap[hap2][j];
	  i = i+2;
	}

      for (i=0; i<num_hap-1; ++i)
	{
	  if (hap1==i && hap2==i) 
	    {
	      x[i]=2;
	      break;
	}
	  if (hap1==i || hap2==i)
	    {
	      x[i]=1;
	    }
	}
      
      /* Generate the interactions */
      for (i=num_hap; i<2*(num_hap-1)+1; ++i)
	{
	  x[i]= x[i-num_hap]*x[num_hap-1];
	}
    
      /* Assign a haplotype to either case or control */
      logitp = log(base_prev/(1-base_prev));
	  
      beta = calloc(2*(num_hap-1)+1, sizeof(double));
      for (i=0; i<2*(num_hap-1)+1; ++i)
	{
	  beta[i] = log(odds_ratio[i]);
	  logitp += x[i]*beta[i];
	}
      prob_case = exp(logitp)/(1+exp(logitp));
      
      y = ignbin(1, (float) prob_case);
      if (y==1 && n1 < num_cases) 
	{
	  ++n1;
	  sample_y[tot_samp] = y;
	  for (j=0; j<2*length_hap; ++j)
	    sample_SNP[tot_samp][j]=genSNP[j];
	  sample_hap1[tot_samp] = hap1;
	  sample_hap2[tot_samp] = hap2;
	  sample_cov[tot_samp] = x[num_hap-1];
	  ++tot_samp;
	}
      if (y==0 && n2 < num_controls) 
	{
	  ++n2;
	  sample_y[tot_samp] = y;
	  for (j=0; j<2*length_hap; ++j)
	    sample_SNP[tot_samp][j]=genSNP[j];
	  sample_hap1[tot_samp] = hap1;
	  sample_hap2[tot_samp] = hap2;
	  sample_cov[tot_samp] = x[num_hap-1];
	  ++tot_samp;
	}      
    }

//////////////////////////////////////////////////////
//Check
//////////////////////////////////////////////////////
/*
int *num_of_each_hap0=calloc(num_hap, sizeof(int));
int *num_of_each_hap1=calloc(num_hap, sizeof(int));

for (i=0; i<num_hap; ++i)
{
    num_of_each_hap0[i]=0;
    num_of_each_hap1[i]=0;
}

for (i=0; i<tot_samp; ++i)
{
    if(sample_cov[i]==0)
    {
        num_of_each_hap0[sample_hap1[i]]++;
        num_of_each_hap0[sample_hap2[i]]++;
    }
    else{
        num_of_each_hap1[sample_hap1[i]]++;
        num_of_each_hap1[sample_hap2[i]]++;    
    }
}

for (i=0; i<num_hap; ++i)
{
    printf("#hap%d when E=0 is %d\n", i, num_of_each_hap0[i]);
    printf("#hap%d when E=1 is %d\n", i, num_of_each_hap1[i]);
}*/

  /* write the total generated sample in outfile */
  outfile = fopen(data[2], "w");

  fprintf(outfile, "affected ");
  fprintf(outfile, "cov ");
  for (i=0; i<length_hap; ++i)
    fprintf(outfile, "M%d.1 M%d.2 ", i+1, i+1);  
  fprintf(outfile, "\n");
  for (i=0; i<tot_samp; ++i)
    {
      fprintf(outfile, "%d ", sample_y[i]);
      fprintf(outfile, "%d ", sample_cov[i]);
      for (j=0; j<2*length_hap; ++j)
	fprintf(outfile, "%d ", sample_SNP[i][j]);
      fprintf(outfile, "\n");
    }
  fclose(outfile);

  return 0;
}

unsigned long long rdtsc(){
    unsigned int lo,hi;
    __asm__ __volatile__ ("rdtsc" : "=a" (lo), "=d" (hi));
    return ((unsigned long long)hi << 32) | lo;
}
